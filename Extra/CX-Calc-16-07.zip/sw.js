self.addEventListener("fetch", function(event) {
  // Let requests pass through
});
